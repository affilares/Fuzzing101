<!--
Read me first!

Before you create a new issue, please make sure to search in https://gitlab.com/michenriksen/jdam/issues,
to verify that the issue you are about to submit isn't a duplicate.
-->

### Summary

<!-- Describe in short the feature you are proposing -->

### Proposal

<!--
Describe the problem you are trying to solve

Benefits if the feature existed.

End result of the proposed feature.
-->

### References

<!-- Provide references related to this proposal -->

/label ~feature