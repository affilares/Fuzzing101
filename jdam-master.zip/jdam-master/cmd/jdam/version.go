package main

var version = "v0.2.0-dev"
